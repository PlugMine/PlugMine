# Plug & Mine – Community Mining & Bitget Trading App
Canvas: plug_and_mine_readme